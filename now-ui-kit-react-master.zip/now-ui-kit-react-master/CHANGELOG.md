# Change Log

## [1.0.0] 2019-07-23
### Original Release
- Started project with create-react-app
- Added Reactstrap as base framework
- Added design from Now UI Kit by Creative Tim
- Added React Hooks
